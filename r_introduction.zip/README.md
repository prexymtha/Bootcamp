# r_introduction


This code serves as the primary tutorial notes for the "Introduction to R" sessions of the Intensive Statistics course for MCom (Economics) students at Stellenbosch University (2025). This lecture is intended to offer a cursory introduction to enable students to perform basic operations in R and RStudio.
date: "2025-01-21"